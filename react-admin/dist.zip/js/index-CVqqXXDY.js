import{j as r}from"./index-CajbBNo_.js";import"./vendor-CG2HWXKd.js";import"./antd-DSVGOj_o.js";function a(){return r.jsx(r.Fragment,{children:"quanixan"})}export{a as default};
