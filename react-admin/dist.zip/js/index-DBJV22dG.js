import{j as o}from"./index-B4s2Fr9x.js";import"./vendor-BD33hX-t.js";import"./antd-Cjmgrhpr.js";function m(){return o.jsx("div",{children:"客房信息"})}export{m as default};
