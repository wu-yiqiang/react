import{j as o}from"./index-C1jJeSdp.js";import"./vendor-rD8zPbUY.js";import"./antd-DVEwm3yD.js";function m(){return o.jsx("div",{children:"客房信息"})}export{m as default};
