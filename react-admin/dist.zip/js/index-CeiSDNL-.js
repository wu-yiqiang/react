import{j as o}from"./index-DhMc-nmY.js";import"./vendor-BD33hX-t.js";import"./antd-bXoFqT91.js";function m(){return o.jsx("div",{children:"客房信息"})}export{m as default};
