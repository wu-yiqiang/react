import{j as t}from"./index-rDD80ERB.js";import"./vendor-CG2HWXKd.js";import"./antd-DSVGOj_o.js";function m(){return t.jsx("div",{children:"客房入住管理"})}export{m as default};
