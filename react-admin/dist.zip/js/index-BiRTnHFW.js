import{j as t}from"./index-DG7iWn8v.js";import"./vendor-BD33hX-t.js";import"./antd-BhWYjOJH.js";function m(){return t.jsx("div",{children:"客房入住管理"})}export{m as default};
