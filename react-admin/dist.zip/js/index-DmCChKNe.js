import{j as t}from"./index-DhMc-nmY.js";import"./vendor-BD33hX-t.js";import"./antd-bXoFqT91.js";function m(){return t.jsx("div",{children:"客房入住管理"})}export{m as default};
