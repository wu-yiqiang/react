import{j as r}from"./index-Dl_7Evj3.js";import"./vendor-QiBadIP2.js";import"./antd-Bci0pe3p.js";function a(){return r.jsx(r.Fragment,{children:"quanixan"})}export{a as default};
