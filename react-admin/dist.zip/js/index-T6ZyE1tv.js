import{j as o}from"./index-C-Dr0iqd.js";import"./vendor-BD33hX-t.js";import"./antd-Cjmgrhpr.js";function m(){return o.jsx("div",{children:"客房预订"})}export{m as default};
