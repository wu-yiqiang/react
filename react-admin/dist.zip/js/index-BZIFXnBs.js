import{j as t}from"./index-CZBpz2b2.js";import"./vendor-rD8zPbUY.js";import"./antd-DVEwm3yD.js";function m(){return t.jsx("div",{children:"客房入住管理"})}export{m as default};
