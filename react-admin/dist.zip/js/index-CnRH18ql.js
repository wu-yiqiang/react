import{j as r}from"./index-DPHJD9DA.js";import"./vendor-QiBadIP2.js";import"./antd-Bci0pe3p.js";function a(){return r.jsx(r.Fragment,{children:"quanixan"})}export{a as default};
