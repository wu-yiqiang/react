import{r as s}from"./request-KOf291IR.js";const p=o=>s.post("/user/login",o),a=o=>s.post("/upload",o),l=(o,t="get")=>s.get(o,{responseType:"blob"});export{l as d,p as l,a as u};
