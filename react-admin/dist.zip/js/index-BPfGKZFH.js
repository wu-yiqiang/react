import{j as t}from"./index-DtFH1Z7H.js";import"./vendor-QiBadIP2.js";import"./antd-Bci0pe3p.js";function m(){return t.jsx("div",{children:"客房入住管理"})}export{m as default};
