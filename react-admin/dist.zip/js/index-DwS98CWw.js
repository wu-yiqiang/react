function t(){return"Statistics"}export{t as default};
