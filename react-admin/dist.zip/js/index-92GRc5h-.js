import{j as t}from"./index-C-Dr0iqd.js";import"./vendor-BD33hX-t.js";import"./antd-Cjmgrhpr.js";function m(){return t.jsx("div",{children:"客房入住管理"})}export{m as default};
