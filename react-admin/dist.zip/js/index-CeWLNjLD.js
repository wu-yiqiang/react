import{j as t}from"./index-pshWmLdU.js";import"./vendor-Cbf0meNL.js";import"./antd-CyemyFsQ.js";function m(){return t.jsx("div",{children:"客房入住管理"})}export{m as default};
