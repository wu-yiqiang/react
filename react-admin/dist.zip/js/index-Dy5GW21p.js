import{j as o}from"./index-pshWmLdU.js";import"./vendor-Cbf0meNL.js";import"./antd-CyemyFsQ.js";function m(){return o.jsx("div",{children:"客房信息"})}export{m as default};
