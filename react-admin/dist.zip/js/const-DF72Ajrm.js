const l=[{value:"1",label:"目录"},{value:"2",label:"菜单"}],a=[{value:1,label:"启用"},{value:0,label:"禁用"}];export{l as m,a as s};
