import{j as t}from"./index-B4s2Fr9x.js";import"./vendor-BD33hX-t.js";import"./antd-Cjmgrhpr.js";function m(){return t.jsx("div",{children:"客房入住管理"})}export{m as default};
