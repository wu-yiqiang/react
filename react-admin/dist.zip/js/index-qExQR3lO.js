import{j as o}from"./index-BrS3vEuF.js";import"./vendor-CG2HWXKd.js";import"./antd-DSVGOj_o.js";function m(){return o.jsx("div",{children:"客房预订"})}export{m as default};
