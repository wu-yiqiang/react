import{j as o}from"./index-CZBpz2b2.js";import"./vendor-rD8zPbUY.js";import"./antd-DVEwm3yD.js";function m(){return o.jsx("div",{children:"客房预订"})}export{m as default};
