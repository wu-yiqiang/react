import{$ as s}from"./antd-Bci0pe3p.js";const t={info:o=>{s.destroy(),s.info(o)},error:o=>{s.destroy(),s.error(o)},success:o=>{s.destroy(),s.success(o)}};export{t as T};
