import{j as o}from"./index-DPHJD9DA.js";import"./vendor-QiBadIP2.js";import"./antd-Bci0pe3p.js";function m(){return o.jsx("div",{children:"客房信息"})}export{m as default};
