import{j as t}from"./index-Dl_7Evj3.js";import"./vendor-QiBadIP2.js";import"./antd-Bci0pe3p.js";function m(){return t.jsx("div",{children:"客房入住管理"})}export{m as default};
