import{j as r}from"./index-DtFH1Z7H.js";import"./vendor-QiBadIP2.js";import"./antd-Bci0pe3p.js";function a(){return r.jsx(r.Fragment,{children:"quanixan"})}export{a as default};
