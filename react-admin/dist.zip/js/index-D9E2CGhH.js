import{j as o}from"./index-cmJk_b0S.js";import"./vendor-Cbf0meNL.js";import"./antd-CyemyFsQ.js";function m(){return o.jsx("div",{children:"客房预订"})}export{m as default};
