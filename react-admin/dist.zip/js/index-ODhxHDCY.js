const e={type:"email",message:"请输入合法的邮箱"},s=[{required:!0,message:"请输入"}],r=[e,...s];export{r as e,s as r};
