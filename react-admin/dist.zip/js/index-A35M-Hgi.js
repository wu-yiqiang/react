import{j as o}from"./index-DG7iWn8v.js";import"./vendor-BD33hX-t.js";import"./antd-BhWYjOJH.js";function m(){return o.jsx("div",{children:"客房预订"})}export{m as default};
