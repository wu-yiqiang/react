import{a0 as s}from"./antd-DSVGOj_o.js";const t={info:o=>{s.destroy(),s.info(o)},error:o=>{s.destroy(),s.error(o)},success:o=>{s.destroy(),s.success(o)}};export{t as T};
