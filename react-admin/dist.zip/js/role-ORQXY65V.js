class t{id;name;code;remark;menus;status;constructor(){this.id=null,this.name="",this.code="",this.menus=[15],this.remark="",this.status=null}}export{t as R};
