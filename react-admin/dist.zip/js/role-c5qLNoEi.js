class t{id;name;code;remark;menus;status;constructor(){this.id=null,this.name="",this.code="",this.menus=[],this.remark="",this.status=null}}export{t as R};
